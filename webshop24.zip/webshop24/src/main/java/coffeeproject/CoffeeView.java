package coffeeproject;
public class CoffeeView {

	public static void print(String message) {
		// TODO Auto-generated method stub
		// 결과를 나타내주는 메세지를 출력하는 함수
		System.out.printf("==========================%s============================", message);
	}

}
