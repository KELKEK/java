package com.shinhan.controller;

import javax.servlet.http.HttpServlet;

public class Test extends HttpServlet{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
